// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyA9NQsCxg2_cSqRKceJUQ7Vjbj1MrBbAQY",
  authDomain: "foodorder-adf44.firebaseapp.com",
  projectId: "foodorder-adf44",
  storageBucket: "foodorder-adf44.appspot.com",
  messagingSenderId: "871087016590",
  appId: "1:871087016590:web:08bedcd1e0a57fec8617df"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export default app;