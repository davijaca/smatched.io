export const categoryData = [



  {
    name: 'Salmon Piccata Recipe',
    price: '122 €',
    img: 'https://deliciouslittlebites.com/wp-content/uploads/2021/05/Salmon-Piccata-Recipe-Image-1-3-500x500.jpg',
    quantity: '5',
    weight: '250g',
    category: 'Food'
  },
  {
    name: 'coca cola classic',
    price: '24 €',
    img: 'https://www.myamericanmarket.com/26686-large_default/coca-cola-classic.jpg',
    quantity: '45',
    weight: '250ml',
    category: 'Drinks',
  },
  {
    name: 'Goat Cheese Pasta Sauce',
    price: '22 €',
    img: 'https://deliciouslittlebites.com/wp-content/uploads/2016/10/Goat-Cheese-Pasta-Sauce-Recipe-Image-1-3-500x500.jpg',
    quantity: '45',
    weight: '250g',
    category: 'Pasta',
  },
  {
    name: ' Kale Detox Salad ',
    price: '25 €',
    img: 'https://deliciouslittlebites.com/wp-content/uploads/2016/03/Kale-Detox-Salad-Recipe-Image-1-500x500.jpg',
    quantity: '3',
    weight: '250g',
    category: 'Salad',
  },
]