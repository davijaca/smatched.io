import React from 'react';
// import '../Styles/Header.scss';

const Header = () => {
  return (
    <section className="header_container">
      <div className="header_img" />
    </section>
  );
};

export default Header;
