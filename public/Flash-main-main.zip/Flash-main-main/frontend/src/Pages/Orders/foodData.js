export const foodData = [
  //deserts//

  {
    id: 1,
    name: 'Keto Caesar Salad Recipe',
    price: '21',
    img: 'https://deliciouslittlebites.com/wp-content/uploads/2020/06/Keto-Caesar-Salad-Recipe-Images-7-500x500.jpg',
    quantity: 54,
    weight: "250g"
  },

  
  {
    id: 2,
    name: 'snapple lemonade',
    price: '21',
    img: 'https://www.myamericanmarket.com/30449-large_default/snapple-lemonade.jpg',
    quantity: 55,
    weight: "250ml"
  },

  //pasta//

  {
    id: 3,
    name: 'Chicken Enchilada Pasta ',
    price: '72',
    img: 'https://deliciouslittlebites.com/wp-content/uploads/2020/01/Chicken-Enchilada-Pasta-Recipe-Image-5-500x500.jpg',
    quantity: 51,
    weight: "250g"
  },
  

  {
    id: 4,
    name: 'French Toast Casserole',
    price: '12',
    img: 'https://deliciouslittlebites.com/wp-content/uploads/2022/01/French-Toast-Casserole-Recipe-Image-10-500x500.jpg',
    quantity: 1,
    weight: "250g"
  },
  

];


