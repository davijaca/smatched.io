// Front end  
cd frontend  
npm install  
npm install -S react-router-dom  
npm install -S react-router-dom  
npm install redux-persist
npm install axios  
npm i react-icons  
npm i stripe-checkout  
npm i firebase  
npm start

// cd admin

npm install  
npm install -S react-router-dom  
npm install @reduxjs/toolkit react-redux  
npm install redux-persist  
npm install axios  
npm i react-icons  
npm i firebase  
npm start

// Back end - Start server running  
cd server
npm install  
npm install nodemon  
npm install cors
npm install dotenv
npm install crypto-js
npm install moongose
npm install express
npm install jsonwebtoken
npm install stripe
npm start

DO NOT FORGET TO CREATE A .env FILE INSIDE THE SERVER FOLDER  
AND PASTE THE DATABSE_URL THERE  
DATABASE INFO WILL BE PROVIDED IN TEAM CHAT!!!

ps. frontend side: atom, molecules, organisms, templates each one of them has a dummy file deleteMe.txt  
delete that file when you have already added a new file to one of these folders, otherwise let how it is.
